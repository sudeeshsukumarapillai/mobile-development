package com.locationpicture.android.utils;

public class Constants {
    public static final String FOLDER ="Location_Picture";
    public static final String PATH = "/storage/emulated/0/"+FOLDER+"/";
    public static final String FOLDER_NAME = "folder_name";
}
